import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * Created by Gaming on 3/5/2018.
 */
public class CloseWindowListener implements WindowListener{

    public void windowIconified(WindowEvent e){

    }

    public void windowOpened(WindowEvent e){

    }

    public void windowClosed(WindowEvent e){


    }

    public void windowActivated(WindowEvent e){


    }

    public void windowClosing(WindowEvent e){


    }

    public void windowDeactivated(WindowEvent e){


    }

    public void windowDeiconified(WindowEvent e){


    }

}
